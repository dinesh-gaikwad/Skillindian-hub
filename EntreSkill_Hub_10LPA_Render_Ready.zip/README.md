# EntreSkill Hub
Interview-ready Full Stack Skill-to-Startup platform.

## Stack
Django REST Framework + JWT + RBAC, React/Vite, PostgreSQL-ready, Docker, Render.

## Features
- JWT authentication
- Role-based access: student, mentor, admin
- Courses and progress tracking
- Quizzes
- Certificates
- Interview question bank
- Startup/skill recommendations
- REST API
- React dashboard
- Docker + Render deployment configuration

## Local
Backend:
`cd backend && python -m venv venv && pip install -r requirements.txt && python manage.py migrate && python manage.py runserver`

Frontend:
`cd frontend && npm install && npm run dev`

For production, set environment variables from `.env.example`.
