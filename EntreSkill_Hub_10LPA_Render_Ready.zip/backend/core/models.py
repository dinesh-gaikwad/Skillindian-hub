from django.db import models
from django.contrib.auth.models import User
class Course(models.Model):
    title=models.CharField(max_length=200)
    description=models.TextField()
    level=models.CharField(max_length=30,default='Beginner')
    created_at=models.DateTimeField(auto_now_add=True)
    def __str__(self): return self.title
class Enrollment(models.Model):
    user=models.ForeignKey(User,on_delete=models.CASCADE)
    course=models.ForeignKey(Course,on_delete=models.CASCADE)
    progress=models.PositiveIntegerField(default=0)
    completed=models.BooleanField(default=False)
    class Meta: unique_together=('user','course')
class InterviewQuestion(models.Model):
    question=models.CharField(max_length=500)
    answer=models.TextField()
    topic=models.CharField(max_length=100)
    difficulty=models.CharField(max_length=30,default='Medium')
class Certificate(models.Model):
    user=models.ForeignKey(User,on_delete=models.CASCADE)
    course=models.ForeignKey(Course,on_delete=models.CASCADE)
    issued_at=models.DateTimeField(auto_now_add=True)
    certificate_id=models.CharField(max_length=80,unique=True)
