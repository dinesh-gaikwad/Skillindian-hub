from rest_framework import serializers
from .models import Course,Enrollment,InterviewQuestion,Certificate
class CourseSerializer(serializers.ModelSerializer):
    class Meta: model=Course; fields='__all__'
class EnrollmentSerializer(serializers.ModelSerializer):
    class Meta: model=Enrollment; fields='__all__'
class InterviewQuestionSerializer(serializers.ModelSerializer):
    class Meta: model=InterviewQuestion; fields='__all__'
class CertificateSerializer(serializers.ModelSerializer):
    class Meta: model=Certificate; fields='__all__'
