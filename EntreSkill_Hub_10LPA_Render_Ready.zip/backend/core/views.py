from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticated
from .models import Course,Enrollment,InterviewQuestion,Certificate
from .serializers import CourseSerializer,EnrollmentSerializer,InterviewQuestionSerializer,CertificateSerializer
class CourseViewSet(viewsets.ModelViewSet):
    queryset=Course.objects.all().order_by('-created_at'); serializer_class=CourseSerializer
class EnrollmentViewSet(viewsets.ModelViewSet):
    serializer_class=EnrollmentSerializer
    def get_queryset(self): return Enrollment.objects.filter(user=self.request.user)
class InterviewQuestionViewSet(viewsets.ModelViewSet):
    queryset=InterviewQuestion.objects.all(); serializer_class=InterviewQuestionSerializer
class CertificateViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class=CertificateSerializer
    def get_queryset(self): return Certificate.objects.filter(user=self.request.user)
