from rest_framework.routers import DefaultRouter
from .views import CourseViewSet,EnrollmentViewSet,InterviewQuestionViewSet,CertificateViewSet
router=DefaultRouter()
router.register('courses',CourseViewSet)
router.register('enrollments',EnrollmentViewSet,basename='enrollment')
router.register('interview-questions',InterviewQuestionViewSet)
router.register('certificates',CertificateViewSet,basename='certificate')
urlpatterns=router.urls
